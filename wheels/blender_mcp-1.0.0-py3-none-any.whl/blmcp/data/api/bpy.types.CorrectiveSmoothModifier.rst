CorrectiveSmoothModifier(Modifier)
==================================

.. currentmodule:: bpy.types

base classes --- :class:`bpy_struct`, :class:`Modifier`

.. class:: CorrectiveSmoothModifier(Modifier)

   Correct distortion caused by deformation

   .. attribute:: factor

      Smooth effect factor (in [-inf, inf], default 0.5)

      :type: float

   .. attribute:: invert_vertex_group

      Invert vertex group influence (default False)

      :type: bool

   .. data:: is_bind

      (default False, readonly)

      :type: bool

   .. attribute:: iterations

      (in [0, 32767], default 5)

      :type: int

   .. attribute:: rest_source

      Select the source of rest positions (default ``'ORCO'``)

      - ``ORCO``
        Original Coords -- Use base mesh vertex coordinates as the rest position.
      - ``BIND``
        Bind Coords -- Use bind vertex coordinates for rest position.

      :type: Literal['ORCO', 'BIND']

   .. attribute:: scale

      Compensate for scale applied by other modifiers (in [-inf, inf], default 1.0)

      :type: float

   .. attribute:: smooth_type

      Method used for smoothing (default ``'SIMPLE'``)

      - ``SIMPLE``
        Simple -- Use the average of adjacent edge-vertices.
      - ``LENGTH_WEIGHTED``
        Length Weight -- Use the average of adjacent edge-vertices weighted by their length.

      :type: Literal['SIMPLE', 'LENGTH_WEIGHTED']

   .. attribute:: use_only_smooth

      Apply smoothing without reconstructing the surface (default False)

      :type: bool

   .. attribute:: use_pin_boundary

      Excludes boundary vertices from being smoothed (default False)

      :type: bool

   .. attribute:: vertex_group

      Name of Vertex Group which determines influence of modifier per point (default "", never None)

      :type: str

   .. classmethod:: bl_rna_get_subclass(id, default=None, /)
   
      :param id: The RNA type identifier.
      :type id: str
      :param default: The value to return when not found.
      :type default: :class:`bpy.types.Struct` | None
      :return: The RNA type or default when not found.
      :rtype: :class:`bpy.types.Struct`


   .. classmethod:: bl_rna_get_subclass_py(id, default=None, /)
   
      :param id: The RNA type identifier.
      :type id: str
      :param default: The value to return when not found.
      :type default: type | None
      :return: The class or default when not found.
      :rtype: type


Inherited Properties
--------------------

.. hlist::
   :columns: 2

   - :class:`bpy_struct.id_data`
   - :class:`Modifier.name`
   - :class:`Modifier.type`
   - :class:`Modifier.show_viewport`
   - :class:`Modifier.show_render`
   - :class:`Modifier.show_in_editmode`
   - :class:`Modifier.show_on_cage`
   - :class:`Modifier.show_expanded`
   - :class:`Modifier.is_active`
   - :class:`Modifier.use_pin_to_last`
   - :class:`Modifier.is_override_data`
   - :class:`Modifier.use_apply_on_spline`
   - :class:`Modifier.execution_time`
   - :class:`Modifier.persistent_uid`

Inherited Functions
-------------------

.. hlist::
   :columns: 2

   - :class:`bpy_struct.as_pointer`
   - :class:`bpy_struct.driver_add`
   - :class:`bpy_struct.driver_remove`
   - :class:`bpy_struct.get`
   - :class:`bpy_struct.id_properties_clear`
   - :class:`bpy_struct.id_properties_ensure`
   - :class:`bpy_struct.id_properties_ui`
   - :class:`bpy_struct.is_property_hidden`
   - :class:`bpy_struct.is_property_overridable_library`
   - :class:`bpy_struct.is_property_readonly`
   - :class:`bpy_struct.is_property_set`
   - :class:`bpy_struct.items`
   - :class:`bpy_struct.keyframe_delete`
   - :class:`bpy_struct.keyframe_insert`
   - :class:`bpy_struct.keys`
   - :class:`bpy_struct.path_from_id`
   - :class:`bpy_struct.path_from_module`
   - :class:`bpy_struct.path_resolve`
   - :class:`bpy_struct.pop`
   - :class:`bpy_struct.property_overridable_library_set`
   - :class:`bpy_struct.property_unset`
   - :class:`bpy_struct.rna_ancestors`
   - :class:`bpy_struct.type_recast`
   - :class:`bpy_struct.values`
   - :class:`Modifier.bl_rna_get_subclass`
   - :class:`Modifier.bl_rna_get_subclass_py`

